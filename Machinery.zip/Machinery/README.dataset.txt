# Machinery > 2022-11-10 6:02pm
https://universe.roboflow.com/semantic-segmentation/machinery-gc7a1

Provided by a Roboflow user
License: CC BY 4.0

